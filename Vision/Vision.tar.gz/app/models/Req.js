var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;

var ReqSchema   = new Schema({
    req_subject: String,
    req_type: String,
    req_info: String, //this can be changed later to new var
    req_status: String,
        firstname: { type: String, required: true },
        lastname: { type: String, required: true}
});

module.exports = mongoose.model('ReqInfo', ReqSchema);
var ReqInfo1     = require('./Req');
