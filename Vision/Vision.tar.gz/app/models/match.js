var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;
var seekStatus	 = 'Accepted Rejected'.split(' ');

var matches   = new Schema({
	Vol_mobile: Number,
    	DateOpened: Date, 
    	Seek_Status: { type: String, enum: seekStatus },
    	Vol_status: String,
    	ReqID: { type: String, required: true },
 	mobileNum: {type: Schema.Types.ObjectId, ref: 'RegisterInfo'}
});

module.exports = mongoose.model('matches', matches);

