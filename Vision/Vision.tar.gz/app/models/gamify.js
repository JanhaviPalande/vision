var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;

var gamifySchema = new Schema({
	for_user: String,
	from_user: String,
	rating: Number 
});

module.exports = mongoose.model('gamifys', gamifySchema);
