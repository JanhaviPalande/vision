var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;
var genders = 'M F'.split(' ');
var registerTypes = 'Seeker Staff VolunteerInterest Volunteer'.split(' '); 

var RegisterSchema   = new Schema({
	firstname: { type: String, required: true, trim: true },
	lastname: { type: String, required: true, trim: true },
	gender: { type: String, required: true, enum: genders, trim: true },
	dob: 	{ type: Date, required: true},
	mobile:	{ type: Number, required: true, index: { unique: true }},
	email:	{ type: String, match: /\S+@\S+\.\S+/ },
	state:	String, 
	city:	String, 
	pincode:	Number,
	address:	String,
	registerType:	{ type: String, required: true, enum: registerTypes , trim: true },
	secQue1: { type: String, required: true, trim: true },
	secQue2: { type: String, required: true, trim: true },
	secAns1: { type: String, required: true, trim: true },
	secAns2: { type: String, required: true, trim: true },
	offerings: {type: String, trim: true },
	created_at: { type: Date, default: Date.now },
    	last_modified_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model('RegisterInfos', RegisterSchema);

