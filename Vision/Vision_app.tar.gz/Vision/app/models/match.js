var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;

var matches   = new Schema({
	Vol_mobile: Number,
    	DateOpened: String, //this can be changed to DATE
    	Seek_Status: String,
    	Vol_status: String,
    	ReqID: { type: String, required: true },
 	//mobile: {type: Schema.Types.ObjectId, ref: 'registerinfos'}
 	mobileNum: {type: Schema.Types.ObjectId, ref: 'RegisterInfo'}
});

module.exports = mongoose.model('matches', matches);

