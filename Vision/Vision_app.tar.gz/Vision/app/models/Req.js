var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;

var ReqSchema   = new Schema({
    req_subject: String,
    req_type: String,
    req_info: String, //this can be changed later to new var
    req_status: String,
        firstname: { type: String, required: true },
        lastname: { type: String, required: true}
});

module.exports = mongoose.model('ReqInfo', ReqSchema);
var ReqInfo1     = require('./Req');
/*
var router = express.Router();
router.route('/Req')

     // create a bear (accessed at POST http://localhost:8080/api/bears)
              .post(function(req, res) {

                    var user = new ReqInfo1();      // create a new instance of the Bear model
                         user.req_subject = req.body.req_subject;
                         user.req_type = req.body.req_type;
                         user.req_status = req.body.req_status;
                         user.req_info = req.body.req_info;

                                 // save the bear and check for errors
                                    user.save(function(err) {
                                      if (err)
                                               res.send(err);

                                                res.json({ message: 'Request saved!' });
                                                  });
                                                  })

                                                   // get all the bears (accessed at GET http://localhost:8080/api/bears)
                                                        .get(function(req, res) {
                                                              ReqInfo1.find(function(err, Req) {
                                                                    if (err)
                                                                              res.send(err);

                                                                               res.json(Req);
                                                                               res.json({ message: 'Req found!' });
                                                                                       });

                                                                                       });

*/
