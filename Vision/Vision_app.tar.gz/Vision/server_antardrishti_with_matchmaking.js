// server.js
// BASE SETUP
// =============================================================================

var mongoose   = require('mongoose');
mongoose.connect('mongodb://localhost/Vision',function(err){ // connect to our database
	if (err)
		throw err;
	console.log('Successfully connected to MongoDB');
});

var LoginInfo     = require('./app/models/login');
var RegisterInfo     = require('./app/models/register');
var ReqInfo1     = require('./app/models/Req');
var matches     = require('./app/models/match');
var Gamify      = require('./app/models/gamify');

// call the packages we need
var express    = require('express');        // call express
var app        = express();                 // define our app using express
var bodyParser = require('body-parser');

// configure app to use bodyParser()
// this will let us get the data from a POST
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var port = process.env.PORT || 8000;        // set our port

// ROUTES FOR OUR API
// =============================================================================
var router = express.Router();              // get an instance of the express Router

router.get('/', function(req, res) {
    res.json({ message: 'hooray! welcome to our api!' });   
});

router.route('/login')
.get(function(req, res) {
	LoginInfo.find(function(err, login) {
		if (err)
			res.send(err);
		res.json(login);
		res.json({ message: 'User details found!' });
	});
});

router.route('/login/:login')
.get(function(req, res) {
	LoginInfo.findOne({ login: req.params.login }, function(err, login) {
        if (err)
                res.send(err);

//        user.comparePassword(user.password, function(err, isMatch) {
//                if (err)
//                        throw err;
//                console.log(user.password, isMatch);
//        });

        res.json(login);
        res.json({ message: 'User found!' });
        });
});

// Registration API code.
router.route('/register')
// create a user entry while registrations (accessed at POST http://localhost:8080/api/register)
.post(function(req, res) {
	var user = new RegisterInfo();      // create a new instance of the RegisterInfo model
	user.firstname = req.body.firstname;    // set the login name, password, (comes from the request)
	user.lastname = req.body.lastname;
        user.gender = req.body.gender;
        user.dob = req.body.dob;
        user.mobile = req.body.mobile;
        user.email = req.body.email;
        user.state = req.body.state;
        user.city = req.body.city;
        user.pincode = req.body.pincode;
        user.address = req.body.address;
	user.registerType = req.body.registerType;
	user.secQue1 = req.body.secQue1;
	user.secQue2 = req.body.secQue2;
	user.secAns1 = req.body.secAns1;
	user.secAns2 = req.body.secAns2;
	user.offerings = req.body.offerings;

// save the registration details and check for errors
        user.save(function(err) {
		if (err)
			res.send(err);

	        res.json({ message: 'Congratulations!!! Now you are a registered user!' });
		res.json({ message: 'User stored in Register table!' });
         });

        var user = new LoginInfo();      // create a new instance of the RegisterInfo model
        user.login =req.body.mobile ;        // set the login name, password, (comes from the request)
        user.password = req.body.password;

        user.save(function(err) {
                if (err)
                        res.send(err);

                res.json({ message: 'User stored in Login table!' });
        });

	
})

// get all the details of a record (accessed at GET http://localhost:8000/api/register).
.get(function(req, res) {
	RegisterInfo.find(function(err, register) {
		if (err)
			res.send(err);
		res.json(register);
		res.json({ message: 'User details found!' });
	});

});

// API for modify user record.
router.route('/register/:register_mobile')
.get(function(req, res) {
	RegisterInfo.findOne({ mobile: req.params.register_mobile }, function(err, register) {
                if (err)
                        res.send(err);
                res.json(register);
                res.json({ message: 'User details for given mobile number!' });
        });

})

.put(function(req, res) {
	RegisterInfo.findOne({ mobile: req.params.register_mobile }, function(err, register) {
		if (err)
			res.send(err);

        register.firstname = req.body.firstname;    // set the login name, password, (comes from the request)
        register.lastname = req.body.lastname;
        register.gender = req.body.gender;
        register.dob = req.body.dob;
        register.email = req.body.email;
        register.state = req.body.state;
        register.city = req.body.city;
        register.pincode = req.body.pincode;
        register.address = req.body.address;
	register.registerType = req.body.registerType;
        register.secQue1 = req.body.secQue1;
        register.secQue2 = req.body.secQue2;
        register.secAns1 = req.body.secAns1;
        register.secAns2 = req.body.secAns2;
	register.offerings = req.body.offerings;

// save the bear
	register.save(function(err) {
		if (err)
			res.send(err);

		res.json({ message: 'User updated!' });
	});
});
})


//Delete record.
.delete(function(req, res) {
	RegisterInfo.remove({ mobile: req.params.register_mobile },function(err, register) {
		if (err)
			res.send(err);
	});
	LoginInfo.remove({ login: req.params.register_mobile },function(err, register) {
		if(err)
			res.send(err);
	});
	res.json({ message: 'Successfully deleted user information!' });
});


//Get seeker list API
router.route('/seeker_list')
.get(function(req, res) {
        RegisterInfo.find({"registerType": "Seeker"}, function(err, register) {
                if (err)
                        res.send(err);
                res.json(register);
        });

});

//Get Volunteer list API
router.route('/volunteer_list')
.get(function(req, res) {
        RegisterInfo.find({"registerType": "Volunteer"}, function(err, register) {
                if (err)
                        res.send(err);
                res.json(register);
        });

});

//Get Volunteer Interest list API.

router.route('/volunteerInterest_list')
.get(function(req, res) {
        RegisterInfo.find({"registerType": "VolunteerInterest"}, function(err, register) {
                if (err)
                        res.send(err);
                res.json(register);
                //res.json({ message: 'Volunteer list found!' });
        });

});

//Get Staff list API.
router.route('/staff_list')
.get(function(req, res) {
        RegisterInfo.find({"registerType": "Staff"}, function(err, register) {
                if (err)
                        res.send(err);
                res.json(register);
                //res.json({ message: 'Volunteer list found!' });
        });

});

//Request API details
router.route('/Req')
     // create a bear (accessed at POST http://localhost:8080/api/bears)
.post(function(req, res) {
	var user = new ReqInfo1();      // create a new instance of the Bear model
	user.req_subject = req.body.req_subject;
	user.req_type = req.body.req_type;
	user.req_status = req.body.req_status;
	user.req_info = req.body.req_info;
	user.firstname = req.body.firstname;
	user.lastname = req.body.lastname;

// save the bear and check for errors
	user.save(function(err) {
		if (err)
			res.send(err);
		res.json({ message: 'Request saved!' });
	});
})

// get all the bears (accessed at GET http://localhost:8080/api/bears)
.get(function(req, res) {
	ReqInfo1.find(function(err, Req) {
		if (err)
			res.send(err);
                res.json(Req);
		res.json({ message: 'Req found!' });
	});
});


 router.route('/Req/:Req_firstname')
// get the bear with that id (accessed at GET http://localhost:8080/api/bears/:bear_id)
.get(function(req, res) {
	ReqInfo1.findOne(req.params.firstname, function(err, Req) {
//ReqInfo1.findOne({'firstname': 'p' }, function(err, Req) {
		if (err)
			res.send(err);
		res.json(Req);
	});
})

 // update the bear with this id (accessed at PUT http://localhost:8080/api/bears/:bear_id)
.put(function(req, res) {

// use our bear model to find the bear we want
	ReqInfo1.findOne(req.params.firstname, function(err, Req) {
		if (err)
			res.send(err);
		Req.req_subject = req.body.req_subject;
		Req.req_type = req.body.req_type;
		Req.req_status = req.body.req_status;
		Req.firstname = req.body.firstname
		Req.lastname = req.body.lastname
 // save the bear
 		Req.save(function(err) {
			if (err)
				res.send(err);

			res.json({ message: 'Bear updated!' });
		});
	});
});


//Match making API details
router.route('/match')
// get all the bears (accessed at GET http://localhost:8080/api/bears)
.get(function(req, res) {
       matches.find(function(err, Req) {
                if (err)
                        res.send(err);
                res.json(Req);
                res.json({ message: 'Req found!' });
        });
})

.post(function(req, res) {
        var match = new matches();      // create a new instance of the Bear model
	match.DateOpened=req.body.DateOpened;
	match.Seek_Status=req.body.Seek_Status;
        match.Vol_status = req.body.Vol_status;
        match.ReqID= req.body.ReqID;
        match.Vol_mobile = req.body.Vol_mobile;

// save the bear and check for errors
	match.save(function(err) {
		if (err)
			res.send(err);
		res.json({ message: 'Request saved!' });
	});
});



router.route('/match/:mobile')

/*
.get(function(req, res) {
	matches.findOne.populate('mobile').exec(function(err, c) {
		if (err) { return console.log(err); }
		console.log(c.mobile.firstname);
});
//      matches.findOne({Vol_mobile: req.params.Vol_mobile},function(error, result) {
//		matches.populate("Vol_mobile")
//                if (err)
 //                       res.send(err);
//                res.json(Req);
//			});	
        });
*/

.get(function(req, res) {
	matches.findOne({ Vol_mobile: req.params.mobile }).populate('mobileNum').exec(function(err, result){
	//matches.findOne({ _id: req.params.mobile }).populate("mobileNum").exec(function(err, result){
	//matches.find({ Vol_mobile: req.params.mobile }).populate("mobileNum").exec(function(err, result){
	if (err)
                res.send(err);
		res.json(result);
		//console.log(matches.mobileNum);
		//console.log('The creator is %s', matches.mobileNum.firstname);
	})
});


 router.route('/match/:req_id')
// get the bear with that id (accessed at GET http://localhost:8080/api/bears/:bear_id)
.get(function(req, res) {
       matches.findOne({ReqID: req.params.req_id}, function(err, Req) {
//ReqInfo1.findOne({'firstname': 'p' }, function(err, Req) {
                if (err)
                        res.send(err);
                res.json(Req);
        });
})

 // update the bear with this id (accessed at PUT http://localhost:8080/api/bears/:bear_id)
.put(function(req, res) {

// use our bear model to find the bear we want
        ReqInfo1.findOne(req.params.firstname, function(err, Req) {
                if (err)
                        res.send(err);
                Req.req_subject = req.body.req_subject;
                Req.req_type = req.body.req_type;
                Req.req_status = req.body.req_status;
                Req.firstname = req.body.firstname
                Req.lastname = req.body.lastname
 // save the bear
                Req.save(function(err) {
                        if (err)
                                res.send(err);

                        res.json({ message: 'Bear updated!' });
                });
        });
});

//APIs for gamification
router.route('/gamify')
// create a bear (accessed at POST http://localhost:8080/api/bears)
.post(function(req, res) {
	var gamifi= new Gamify();      // create a new instance of the Bear model
	gamifi.for_user = req.body.for_user;
	gamifi.from_user = req.body.from_user;
	gamifi.rating = req.body.rating;
	
// save the bear and check for errors
	gamifi.save(function(err) {
		if (err)
			res.send(err);
		res.json({ message: 'Request saved!' });
	});
})

// get all the bears (accessed at GET http://localhost:8080/api/bears)
.get(function(req, res) {
	Gamify.find(function(err, Req) {
		if (err)
			res.send(err);
		res.json(Req);
		res.json({ message: 'Req found!' });
	});
});

// REGISTER OUR ROUTES -------------------------------
// all of our routes will be prefixed with /api
app.use('/api', router);

// START THE SERVER
// =============================================================================
app.listen(port);
console.log('Magic happens on port ' + port);
